// import 'dart:async';
//
// import 'package:alarm/alarm.dart';
//
// import '../config/prayer_scheduler_config.dart';
// import '../notifications/countdown_notification_service.dart';
// import '../utils/prayer_scheduler_assets.dart';
// import '../utils/prayer_scheduler_ids.dart';
//
// class ReminderScheduler {
//   const ReminderScheduler._();
//
//   static Future<void> schedule({
//     required int dayIndex,
//     required dynamic moment,
//   }) async {
//     final id = PrayerSchedulerIds.reminder(
//       moment.time,
//       moment.index,
//     );
//
//     final reminderTime =
//         moment.time.subtract(const Duration(minutes: 5));
//
//     prayerSchedulerLog(
//       '🔔 REMINDER START | id=$id | prayer=${moment.name} | time=$reminderTime',
//     );
//
//     if (!reminderTime.isAfter(DateTime.now())) {
//       prayerSchedulerLog('⏭️ REMINDER SKIPPED');
//       return;
//     }
//
//     final alarmSettings = AlarmSettings(
//       id: id,
//       dateTime: reminderTime,
//       assetAudioPath: PrayerSchedulerAssets.reminder(moment.name),
//       loopAudio: false,
//       vibrate: false,
//       androidFullScreenIntent: false,
//       androidStopAlarmOnTermination: false,
//       volumeSettings: VolumeSettings.fade(
//         volume: 1.0,
//         fadeDuration: const Duration(seconds: 1),
//         volumeEnforced: true,
//       ),
//       notificationSettings: NotificationSettings(
//         title: 'اقترب موعد صلاة ${moment.name}',
//         body: 'باقي 5 دقائق على أذان ${moment.name}',
//         stopButton: 'إيقاف التنبيه',
//         icon: notificationIcon,
//         androidStopAlarmOnDismiss: false,
//       ),
//       payload: 'reminder_before_adhan',
//     );
//
//     await Alarm.set(alarmSettings: alarmSettings);
//     Timer(const Duration(seconds: 6), () async {
//       if (await Alarm.isRinging(id)) {
//         await Alarm.stop(id);
//       }
//     });
//     prayerSchedulerLog(
//       '✅ REMINDER Alarm.set SUCCESS | id=$id',
//     );
//   }
// }
import 'dart:async';

import 'package:alarm/alarm.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:workmanager/workmanager.dart';

import '../config/prayer_scheduler_config.dart';
import '../notifications/countdown_notification_service.dart';
import '../utils/prayer_scheduler_assets.dart';
import '../utils/prayer_scheduler_ids.dart';

import 'dart:async';
import 'package:alarm/alarm.dart';
import 'package:flutter/cupertino.dart';
import '../config/prayer_scheduler_config.dart';
import '../notifications/countdown_notification_service.dart';
import '../utils/prayer_scheduler_assets.dart';
import '../utils/prayer_scheduler_ids.dart';

class ReminderScheduler {
  const ReminderScheduler._();

  static Future<void> schedule({
    required int dayIndex,
    required dynamic moment,
  }) async {
    final reminderId = PrayerSchedulerIds.reminder(
      moment.time,
      moment.index,
    );

    final adhanId = PrayerSchedulerIds.adhan(
      moment.time,
      moment.index,
    );

    final reminderTime = moment.time.subtract(const Duration(minutes: 5));

    prayerSchedulerLog(
      '🔔 REMINDER START | reminderId=$reminderId | adhanId=$adhanId | prayer=${moment.name} | time=$reminderTime',
    );

    if (!reminderTime.isAfter(DateTime.now())) {
      prayerSchedulerLog('⏭️ REMINDER SKIPPED');
      return;
    }

    final alarmSettings = AlarmSettings(
      id: reminderId,
      dateTime: reminderTime,
      assetAudioPath: PrayerSchedulerAssets.reminder(moment.name),
      loopAudio: false,
      vibrate: false,
      androidFullScreenIntent: false,
      androidStopAlarmOnTermination: false,
      allowAlarmOverlap: true,
      volumeSettings: VolumeSettings.fade(
        volume: 1.0,
        fadeDuration: const Duration(seconds: 1),
        volumeEnforced: true,
      ),
      notificationSettings: NotificationSettings(
        title: 'اقترب موعد صلاة ${moment.name}',
        body: 'باقي 5 دقائق على أذان ${moment.name}',
        stopButton: 'إيقاف التنبيه',
        icon: notificationIcon,
        androidStopAlarmOnDismiss: false,
      ),
      payload: 'reminder_before_adhan|$adhanId',
    );

    await Alarm.set(alarmSettings: alarmSettings);

    prayerSchedulerLog(
      '✅ REMINDER Alarm.set SUCCESS | id=$reminderId',
    );
  }
}

class ReminderAutoStop {
  static bool _attached = false;

  static void attachOnce() {
    if (_attached) return;
    _attached = true;

    Alarm.ringing.listen((alarmSet) {
      for (final alarm in alarmSet.alarms) {
        handleAlarmRing(alarm);
      }
    });
  }

  @pragma('vm:entry-point')
  static Future<void> handleAlarmRing(AlarmSettings alarm) async {
    // ✅ نتأكد أن هذا تذكير
    if (!alarm.payload!.startsWith('reminder_before_adhan')) return;

    final parts = alarm.payload?.split('|');
    final adhanId = int.tryParse(parts![1]);

    debugPrint('🔔 REMINDER RINGING | id=${alarm.id} | adhanId=$adhanId');

    // ✅ انتظر 3 ثوانٍ
    await Future.delayed(const Duration(seconds: 3));

    // ✅ أوقف التذكير إذا كان لا يزال يرن
    final stillRinging = await Alarm.isRinging(alarm.id);

    if (stillRinging) {
      await Alarm.stop(alarm.id);
      debugPrint('✅ REMINDER STOPPED (auto) | id=${alarm.id}');
    } else {
      debugPrint('🛑 REMINDER ALREADY STOPPED BY USER | id=${alarm.id}');
    }

    // ✅ التحقق من أن الأذان لا يزال مجدولاً
    try {
      final allAlarms = await Alarm.getAlarms();
      final adhanExists = allAlarms.any((a) => a.id == adhanId);

      if (adhanExists) {
        debugPrint('✅ ADHAN IS STILL SCHEDULED | adhanId=$adhanId');
      } else {
        debugPrint('⚠️ ADHAN NOT FOUND - SCHEDULING CHECK | adhanId=$adhanId');
        if (adhanId != null) {
          await BackgroundService.scheduleAdhanCheck(adhanId);
        }
      }
    } catch (e) {
      debugPrint('❌ ERROR CHECKING ALARMS: $e');
    }

    debugPrint('🔊 ADHAN WILL RING AUTOMATICALLY | adhanId=$adhanId');
  }
}


@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == 'playAdhan') {
      final adhanId = inputData?['adhanId'] as int?;
      if (adhanId != null) {
        // ✅ الحصول على جميع المنبهات المجدولة والبحث عن المنبه المطلوب
        try {
          final allAlarms = await Alarm.getAlarms();
          final alarm = allAlarms.firstWhere(
                (a) => a.id == adhanId,

          );

          if (alarm != null && !await Alarm.isRinging(adhanId)) {
            await Alarm.set(alarmSettings: alarm);
            debugPrint('🔊 ADHAN RE-SCHEDULED FROM BACKGROUND | id=$adhanId');
          } else if (alarm == null) {
            debugPrint('⚠️ ADHAN NOT FOUND IN BACKGROUND | id=$adhanId');
          }
        } catch (e) {
          debugPrint('❌ ERROR IN BACKGROUND TASK: $e');
        }
      }
    }
    return Future.value(true);
  });
}

class BackgroundService {
  static bool _initialized = false;
  static int _alarmIdCounter = 1000;

  static Future<void> initialize() async {
    if (_initialized) return;

    try {
      // ✅ تهيئة Android Alarm Manager
      await AndroidAlarmManager.initialize();
      _initialized = true;
      debugPrint('✅ ANDROID ALARM MANAGER INITIALIZED SUCCESSFULLY');
    } catch (e) {
      debugPrint('❌ ERROR INITIALIZING ALARM MANAGER: $e');
      // لا نعيد رمي الخطأ
    }
  }

  static Future<void> scheduleAdhanCheck(int adhanId) async {
    try {
      final int taskId = _alarmIdCounter++;

      // ✅ جدولة مهمة للتحقق من الأذان بعد 10 ثوانٍ
      await AndroidAlarmManager.oneShot(
        const Duration(seconds: 10),
        taskId,
            () async {
          debugPrint('🔊 CHECKING ADHAN IN BACKGROUND | adhanId=$adhanId | taskId=$taskId');

          try {
            // ✅ الحصول على جميع المنبهات المجدولة
            final allAlarms = await Alarm.getAlarms();
            debugPrint('📋 ALL ALARMS: ${allAlarms.map((a) => a.id).toList()}');

            // ✅ البحث عن الأذان
            final alarm = allAlarms.firstWhere(
                  (a) => a.id == adhanId,
            );

            if (alarm != null) {
              // التحقق إذا كان الأذان لا يزال يرن
              final isRinging = await Alarm.isRinging(adhanId);

              if (!isRinging) {
                // ✅ إعادة جدولة الأذان
                await Alarm.set(alarmSettings: alarm);
                debugPrint('🔊 ADHAN RE-SCHEDULED FROM BACKGROUND | id=$adhanId');
              } else {
                debugPrint('🔊 ADHAN IS ALREADY RINGING | id=$adhanId');
              }
            } else {
              debugPrint('⚠️ ADHAN NOT FOUND IN SCHEDULED ALARMS | id=$adhanId');
            }
          } catch (e) {
            debugPrint('❌ ERROR IN BACKGROUND TASK: $e');
          }
        },
        exact: true,
        wakeup: true,
      );

      debugPrint('✅ ADHAN CHECK SCHEDULED | adhanId=$adhanId | taskId=$taskId');
    } catch (e) {
      debugPrint('❌ ERROR SCHEDULING ADHAN CHECK: $e');
    }
  }
}