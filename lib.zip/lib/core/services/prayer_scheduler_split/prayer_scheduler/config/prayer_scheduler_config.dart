const String prayerNotificationWindowPrefsKey =
    'prayer_notifications_window_json';

const String prayerScheduledDaysPrefsKey =
    'prayer_notifications_scheduled_days';

const String prayerScheduledFromPrefsKey =
    'prayer_notifications_scheduled_from';



const String countdownChannelId = 'prayer_countdown_channel';
const String countdownChannelName = 'الصلاة القادمة';
const String countdownChannelDescription = 'عداد تنازلي للصلاة القادمة';
const int countdownNotificationId = 1000;
const String prayerLastLatitudePrefsKey = 'prayer_last_latitude';
const String prayerLastLongitudePrefsKey = 'prayer_last_longitude';
const int adhanIdBase = 100000;
const int reminderIdBase = 200000;
const int iqamaIdBase = 300000;
const int countdownUpdateIdBase = 400000;

const String notificationIcon = 'ic_mosque_notification';

const String adhanAsset =
    'assets/adhan-mp3/abdul_majid_al_surehi_1.mp3';

const String iqamaAsset =

     'assets/adhan-mp3/Iqama.mp3';

const String reminderAsset =

    'assets/prayer_time_soon/fajr.mp3';
