import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/widgets.dart' as widgets;
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/services/adhan_scheduler_service.dart';
import '../../../../core/services/prayer_scheduler_split/prayer_scheduler/adhan_scheduler_service.dart';
import '../../../../core/services/prayer_scheduler_split/prayer_scheduler/config/prayer_scheduler_config.dart';
import '../../../../injection_container.dart';
import '../../../locations/domain/entity/location_entity.dart';
import '../../../prayer_times/presentation/bloc/prayer_bloc.dart';
import '../../../prayer_times/presentation/widgets/prayer_times_widget.dart';
import '../widget/buildBottomNavigation.dart';
import '../widget/buildDateLocation.dart';
import '../widget/build_mainGrid.dart';
import '../widget/getCurrentHijriDate.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomePage> with RouteAware {
  Timer? _timer;

  int selectedNavIndex = 0;

  bool _adhanScheduled = false;

  double _latitude = 30.0444;
  double _longitude = 31.2357;
  bool _locationReady = false;
  static const String _locationModeKey = 'prayer_location_mode';
  static const String _locationModeAuto = 'auto';
  static const String _locationModeManual = 'manual';



  @override
  void dispose() {
    debugPrint(
      '💀💀💀 HOME PAGE DISPOSE: ${identityHashCode(this)}',
    );
    _timer?.cancel();
    super.dispose();
  }

  late final PrayerBloc _prayerBloc;

  @override
  void initState() {
    super.initState();

    debugPrint(
      '🏠🏠🏠 HOME PAGE INIT: ${identityHashCode(this)}',
    );
    _prayerBloc = sl<PrayerBloc>();
    _loadLocationAndPrayerTimes();
  }


  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: _prayerBloc,
      child: BlocListener<PrayerBloc, PrayerState>(
        listener: (context, state) async {
          if (state is! PrayerLoaded) {
            return;
          }

          debugPrint(
            '🕌 PRAYER LOADED | '
                'lat=$_latitude | '
                'lng=$_longitude',
          );

          final service = AdhanSchedulerService();

          try {
            debugPrint('🔔 SCHEDULING ADHAN...');

            await service.showNextPrayerCountdown(
              state.prayerTimes,
            );

            await service.schedulePrayerAdhan(
              state.prayerTimes,
              latitude: _latitude,
              longitude: _longitude,
            );

            _adhanScheduled = true;

            debugPrint('✅ ADHAN SCHEDULED SUCCESSFULLY');
          } catch (e, stackTrace) {
            _adhanScheduled = false;

            debugPrint('❌ ADHAN SCHEDULING FAILED: $e');
            debugPrint('$stackTrace');
          }
        },
        child: Directionality(
          textDirection: widgets.TextDirection.rtl,
          child: Scaffold(
            backgroundColor: const Color(0xFFE8E8CE),
            body: SafeArea(
              child: BlocBuilder<PrayerBloc, PrayerState>(
                builder: (context, state) {
                  if (state is PrayerLoading) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }

                  if (state is PrayerError) {
                    return Center(
                      child: Text(
                        state.message,
                        textAlign: TextAlign.center,
                      ),
                    );
                  }

                  if (state is PrayerLoaded) {
                    final prayerTimes = state.prayerTimes;

                    return Column(
                      children: [
                        Expanded(
                          child: SingleChildScrollView(
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 8),
                                _buildTopBar(),
                                ElevatedButton(
                                  onPressed: () async {
                                    await AutoRenewTest.run();
                                  },
                                  child: const Text(
                                    '🧪 اختبار Auto-Renew',
                                  ),
                                ),
                                const SizedBox(height: 18),
                                NextPrayerCard(
                                  prayerTimes: prayerTimes,
                                ),
                                const SizedBox(height: 18),
                                _buildSectionTitle(
                                  'مواقيت الصلاة',
                                ),
                                const SizedBox(height: 10),
                                PrayerTimesWidget(
                                  prayerTimes: prayerTimes,
                                ),
                                const SizedBox(height: 18),
                                BuildMainGrid(),
                                const SizedBox(height: 10),
                              ],
                            ),
                          ),
                        ),
                      ],
                    );
                  }

                  return const Center(
                    child: Text('جاري التحميل...'),
                  );
                },
              ),
            ),
            bottomNavigationBar: CustomBottomNavigation(
              selectedIndex: selectedNavIndex,
              onSelected: (index) {
                setState(() {
                  selectedNavIndex = index;
                });
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Row(
      children: [
     IconButton(
              onPressed: _openLocationPage,
              icon:Icon(
                Icons.location_on_outlined,
                size: 25,
                color: Color(0xFF222222),
              )

          ),

        const Spacer(),
        Column(
          children: [
            Text(
              getCurrentHijriDate(),
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade700,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const Spacer(),
        IconButton(
          onPressed: () {},
          icon: const Icon(
            Icons.notifications_none_rounded,
            size: 25,
            color: Color(0xFF222222),
          ),
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: Color(0xFF222222),
      ),
    );
  }
  Future<void> _openLocationPage() async {
    final result = await Navigator.pushNamed(
      context,
      AppRouter.locationPage,
    );

    if (!mounted || result == null) {
      return;
    }

    if (result is! LocationEntity) {
      debugPrint(
        '❌ Invalid location result: ${result.runtimeType}',
      );
      return;
    }

    final location = result;

    final lat = location.latitude;
    final lng = location.longitude;

    debugPrint(
      '📍 NEW LOCATION | '
          'city=${location.city} | '
          'country=${location.country} | '
          'lat=$lat | '
          'lng=$lng',
    );

    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(
      _locationModeKey,
      _locationModeManual,
    );

    await prefs.setDouble(
      'prayer_manual_latitude',
      lat,
    );

    await prefs.setDouble(
      'prayer_manual_longitude',
      lng,
    );

    await prefs.setDouble(
      prayerLastLatitudePrefsKey,
      lat,
    );

    await prefs.setDouble(
      prayerLastLongitudePrefsKey,
      lng,
    );

    if (!mounted) return;

    setState(() {
      _latitude = lat;
      _longitude = lng;
      _locationReady = true;

      // مهم جدًا
      _adhanScheduled = false;
    });

    // 1️⃣ إلغاء كل alarms القديمة
    debugPrint('🗑️ CANCEL OLD ADHAN ALARMS');

    try {
      await AdhanSchedulerService().cancelAdhans();
      debugPrint('✅ OLD ADHAN ALARMS CANCELLED');
    } catch (e, stackTrace) {
      debugPrint('❌ CANCEL OLD ALARMS FAILED: $e');
      debugPrint('$stackTrace');
    }

    // 2️⃣ حساب مواقيت الصلاة للموقع الجديد
    debugPrint(
      '🕌 LOAD NEW PRAYER TIMES | '
          'lat=$lat | lng=$lng',
    );

    _prayerBloc.add(
      LoadPrayerTimes(
        latitude: lat,
        longitude: lng,
        date: DateTime.now(),
      ),
    );
  }
  Future<void> _loadLocationAndPrayerTimes() async {
    final prefs = await SharedPreferences.getInstance();

    final mode =
        prefs.getString(_locationModeKey) ?? _locationModeAuto;

    debugPrint(
      '📍 HOME LOCATION | mode=$mode',
    );

    if (mode == _locationModeManual) {
      _latitude =
          prefs.getDouble('prayer_manual_latitude') ?? _latitude;

      _longitude =
          prefs.getDouble('prayer_manual_longitude') ?? _longitude;

      debugPrint(
        '📍 HOME MANUAL LOCATION | '
            'lat=$_latitude | '
            'lng=$_longitude',
      );
    } else {
      await _useAutomaticLocation(showError: false);

      debugPrint(
        '📍 HOME GPS LOCATION | '
            'lat=$_latitude | '
            'lng=$_longitude',
      );
    }

    _locationReady = true;

    await _reloadPrayerTimesAndAlarms();
  }
  Future<void> _useAutomaticLocation({bool showError = true}) async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw Exception('يرجى تشغيل خدمة الموقع GPS');
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        throw Exception('لم يتم السماح بالوصول إلى الموقع');
      }
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
      );
      _latitude = position.latitude;
      _longitude = position.longitude;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_locationModeKey, _locationModeAuto);
      await prefs.setDouble(prayerLastLatitudePrefsKey, _latitude);
      await prefs.setDouble(prayerLastLongitudePrefsKey, _longitude);
    } catch (e) {
      if (showError && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }
  Future<void> _reloadPrayerTimesAndAlarms() async {
    if (!_locationReady) return;
    _adhanScheduled = false;
    _prayerBloc.add(LoadPrayerTimes(
      latitude: _latitude,
      longitude: _longitude,
      date: DateTime.now(),
    ));
  }

}