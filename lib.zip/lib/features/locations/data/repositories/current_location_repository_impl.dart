import '../../domain/entity/current_location_entity.dart';
import '../../domain/repositories/current_location_repository.dart';
import '../datasources/current_location_data_source.dart';

class CurrentLocationRepositoryImpl
    implements CurrentLocationRepository {
  final CurrentLocationDataSource dataSource;

  CurrentLocationRepositoryImpl({
    required this.dataSource,
  });

  @override
  Future<CurrentLocationEntity>
  getCurrentLocation() async {
    final position =
    await dataSource.getCurrentLocation();

    return CurrentLocationEntity(
      latitude: position.latitude,
      longitude: position.longitude,
    );
  }
}