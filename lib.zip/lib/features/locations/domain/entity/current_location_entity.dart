import 'package:equatable/equatable.dart';

class CurrentLocationEntity extends Equatable {
  final double latitude;
  final double longitude;

  const CurrentLocationEntity({
    required this.latitude,
    required this.longitude,
  });

  @override
  List<Object?> get props => [
    latitude,
    longitude,
  ];
}