import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../domain/entities/hijri_date_entity.dart';
import '../../domain/usecases/get_hijri_date.dart';
import '../../domain/usecases/get_hijri_month.dart';

import '../../../prayer_times/domain/entities/prayer_times_entity.dart';
import '../../../prayer_times/domain/usecases/get_prayer_times.dart';

import 'hijri_calendar_event.dart';
import 'hijri_calendar_state.dart';

class HijriCalendarBloc
    extends Bloc<HijriCalendarEvent, HijriCalendarState> {
  final GetHijriDate getHijriDate;
  final GetHijriMonth getHijriMonth;
  final GetPrayerTimes getPrayerTimes;

  HijriCalendarBloc({
    required this.getHijriDate,
    required this.getHijriMonth,
    required this.getPrayerTimes,
  }) : super(const HijriCalendarInitial()) {
    on<LoadHijriCalendar>(_onLoad);
    on<SelectHijriDate>(_onSelectDate);
    on<NextHijriMonth>(_onNextMonth);
    on<PreviousHijriMonth>(_onPreviousMonth);
  }


  Future<void> _onLoad(
      LoadHijriCalendar event,
      Emitter<HijriCalendarState> emit,
      ) async {
    emit(const HijriCalendarLoading());

    try {
      final today = DateTime.now();

      // Get saved location
      final prefs = await SharedPreferences.getInstance();

      final latitude =
          prefs.getDouble('prayer_manual_latitude') ?? 30.0444;

      final longitude =
          prefs.getDouble('prayer_manual_longitude') ?? 31.2357;

      debugPrint(
        '📍 HIJRI CALENDAR LOCATION | '
            'lat=$latitude | lng=$longitude',
      );

      final hijriDate = getHijriDate(today);

      final dates = getHijriMonth(
        year: hijriDate.year,
        month: hijriDate.month,
      );

      final prayerTimes = await getPrayerTimes(
        latitude: latitude,
        longitude: longitude,
        date: today,
      );

      emit(
        HijriCalendarLoaded(
          dates: dates,
          year: hijriDate.year,
          month: hijriDate.month,
          selectedDate: hijriDate,
          prayerTimes: prayerTimes,
        ),
      );
    } catch (e) {
      emit(
        HijriCalendarError(
          'حدث خطأ أثناء تحميل التقويم: $e',
        ),
      );
    }
  }

  Future<void> _onSelectDate(
      SelectHijriDate event,
      Emitter<HijriCalendarState> emit,
      ) async {
    final currentState = state;

    if (currentState is! HijriCalendarLoaded) {
      return;
    }

    try {
      final selectedHijriDate = getHijriDate(event.date);

      // Get latest saved location
      final prefs = await SharedPreferences.getInstance();

      final latitude =
          prefs.getDouble('prayer_manual_latitude') ?? 30.0444;

      final longitude =
          prefs.getDouble('prayer_manual_longitude') ?? 31.2357;

      debugPrint(
        '📍 HIJRI SELECT DATE LOCATION | '
            'lat=$latitude | lng=$longitude',
      );

      final prayerTimes = await getPrayerTimes(
        latitude: latitude,
        longitude: longitude,
        date: event.date,
      );

      emit(
        currentState.copyWith(
          selectedDate: selectedHijriDate,
          prayerTimes: prayerTimes,
        ),
      );
    } catch (e) {
      emit(
        HijriCalendarError(
          'حدث خطأ أثناء تحميل مواقيت الصلاة: $e',
        ),
      );
    }
  }

  Future<void> _onNextMonth(
      NextHijriMonth event,
      Emitter<HijriCalendarState> emit,
      ) async {
    final currentState = state;

    if (currentState is! HijriCalendarLoaded) {
      return;
    }

    int month = currentState.month + 1;
    int year = currentState.year;

    if (month > 12) {
      month = 1;
      year++;
    }

    final dates = getHijriMonth(
      year: year,
      month: month,
    );

    emit(
      currentState.copyWith(
        dates: dates,
        year: year,
        month: month,
        selectedDate: dates.isNotEmpty ? dates.first : null,
        prayerTimes: null,
      ),
    );
  }

  Future<void> _onPreviousMonth(
      PreviousHijriMonth event,
      Emitter<HijriCalendarState> emit,
      ) async {
    final currentState = state;

    if (currentState is! HijriCalendarLoaded) {
      return;
    }

    int month = currentState.month - 1;
    int year = currentState.year;

    if (month < 1) {
      month = 12;
      year--;
    }

    final dates = getHijriMonth(
      year: year,
      month: month,
    );

    emit(
      currentState.copyWith(
        dates: dates,
        year: year,
        month: month,
        selectedDate: dates.isNotEmpty ? dates.first : null,
        prayerTimes: null,
      ),
    );
  }
}